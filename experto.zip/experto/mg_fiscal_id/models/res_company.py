# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions, _


class ResCompany(models.Model):
    _inherit = 'res.company'

    nif = fields.Char(string="Nif")
    stat = fields.Char(string="Stat")
    rcs = fields.Char(string="RCS")
