Make MRP orders from POS v12
============================
From the POS sale we need to generate MRP orders in the back end with out close the current window.

Features
========

* Automatically create MRP order form POS sale.
* We can assign which products make MRP order Automatically.

Credits
=======
V10 Nikhil Krishnan @ cybrosys, odoo@cybrosys.com
V12 Akshay Babu
