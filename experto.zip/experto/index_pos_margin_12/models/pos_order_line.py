# -*- coding: UTF-8 -*-
from odoo import api, fields, models
import odoo.addons.decimal_precision as dp

class PosOrderLine(models.Model):
    _inherit = 'pos.order.line'

    # Columns Section
    margin = fields.Float(
        string='Margin',
        compute='_compute_multi_margin',
        store=True,
        digits=dp.get_precision('Product Price'),
    )

    purchase_price = fields.Float(
        string='Cost Price',
        compute='_compute_multi_margin',
        store=True,
        digits=dp.get_precision('Product Price'),
    )

    # Compute Section
    @api.multi
    @api.depends('product_id', 'qty', 'price_subtotal')
    def _compute_multi_margin(self):
        for line in self.filtered('product_id'):
            purchase_price = self._get_purchase_price(line)
            margin = line.price_subtotal - (purchase_price * line.qty)
            line.update({
                'purchase_price': purchase_price,
                'margin': margin,
            })

    @api.model
    def _get_purchase_price(self, line):
        SaleOrderLine = self.env['sale.order.line']

        uom = hasattr(line, 'uom_id') and line.uom_id \
              or line.product_id.uom_id

        return SaleOrderLine._get_purchase_price(
            line.order_id.pricelist_id, line.product_id, uom,
            line.order_id.date_order)['purchase_price']
