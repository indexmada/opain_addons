# -*- coding: UTF-8 -*-

from odoo import models, fields


class PosOrderReport(models.Model):
    _inherit = "report.pos.order"

    margin = fields.Float(string='Margin', readonly=True)

    def _select(self):
        return super(PosOrderReport, self)._select() + """,
                l.margin
        """

    def _group_by(self):
        return super(PosOrderReport, self)._group_by() + """,
                l.margin
        """
