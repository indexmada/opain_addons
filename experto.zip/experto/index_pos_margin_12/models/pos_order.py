# -*- coding: UTF-8 -*-
from odoo import api, fields, models
import odoo.addons.decimal_precision as dp


class PosOrder(models.Model):
    _inherit = 'pos.order'

    # Columns Section
    margin = fields.Float(
        string='Margin',
        compute='_compute_margin',
        store=True,
        digits=dp.get_precision('Product Price'),
        help="It gives profitability by calculating the difference between"
             " the Unit Price and the cost price.")

    # Compute Section
    @api.multi
    @api.depends('lines.margin', 'lines.price_subtotal')
    def _compute_margin(self):
        for order in self:
            tmp_margin = sum(order.mapped('lines.margin'))
            order.update({
                'margin': tmp_margin,
            })
