{
    'name': 'PoS Order Margin',
    'summary': 'Margin on PoS Order',
    'version': '12.0.1.0.0',
    'category': 'Point Of Sale',
    'author': "m0r7y",

    'depends': [
        'point_of_sale',
        'sale_margin',
    ],
    'data': [
        'views/view_pos_order.xml',
        'views/pos_product_report_view.xml',
    ],
    'application': True,
    'installable': True,
}
