`1.0.1`
-------

**Fix:** it was impossible to create postponed Payment Method other than Cash

`1.0.0`
-------

- **Init version**
