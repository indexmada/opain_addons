* coalesced to a single file
* converted to odoo client modules
* trimmed to only the parts we use (mostly) e.g. removal of the API init 
  parameter
* provision of a default patch function (as `snabbdom`).
