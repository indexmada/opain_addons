odoo.define('index_custom_ticket.ticket', function(require) {
"use strict";


var models = require('point_of_sale.models');
var session = require('web.session');
var rpc = require('web.rpc');

var _super_PosModel = models.PosModel.prototype;

models.PosModel = models.PosModel.extend({
    initialize: function (session, attributes) {
        var product_model = _.find(this.models, function(model){
            return model.model === 'res.company';
        });
        product_model.fields.push('logo');
        return _super_PosModel.initialize.call(this, session, attributes);
    }

});
})