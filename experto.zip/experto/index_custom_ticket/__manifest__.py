# -*- coding: utf-8 -*-
{
    'name': "Index Custom Ticket V12",

    'summary': """
        Index Custom Ticket V12""",

    'description': """
    """,

    'author': "Fenosoa RAHARIJAONA",

    'category': 'Point of Sale',
    'version': '12.0.1.1.0',

    'depends': [
        'point_of_sale',
    ],

    'data': [
        'views/index_custom_ticket_templates.xml',
    ],
    'qweb': [
        'static/src/xml/pos_ticket.xml',
    ]
}
