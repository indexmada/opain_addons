# -*- coding: utf-8 -*-
{
    'name': "Convert V2",

    'summary': """
        Toolkit needed to convert python datas, such as: \n
            - grouplines\n
            - amount_to_text (in malagasy format)\n
            - and so one...""",

    'author': "Fenosoa Raharijaona",

    'category': 'Tools',
    'version': '12.0.1.0.0',

    'depends': [
                'base',
    ],

    'data': [
    ],
    'auto_install': True,
}
