# -*- coding: utf-8 -*-
from itertools import groupby


def grouplines(lines, sortkey):
    """
    Group lines by sortkey.

    @param lines: object instance to group
    @param sortkey: object with what we group lines
    @return:  {'sortkey': sortkey1, 'lines': [line1, line2]}
    @rtype:  dictionnary
    """
    grouped_lines = []
    for key, valuesiter in groupby(lines, sortkey):
        group = {}
        group['sortkey'] = key
        group['lines'] = list(v for v in valuesiter)
        grouped_lines.append(group)
    return grouped_lines

# -------------------------------------------------------------
# Malagasy Amount to text
# -------------------------------------------------------------


to_19_mg = (u'Zéro', 'Un', 'Deux', 'Trois', 'Quatre', 'Cinq', 'Six',
            'Sept', 'Huit', 'Neuf', 'Dix', 'Onze', 'Douze', 'Treize',
            'Quatorze', 'Quinze', 'Seize', 'Dix-sept', 'Dix-huit', 'Dix-neuf')
tens_mg = ('Vingt', 'Trente', 'Quarante', 'Cinquante', 'Soixante', 'Soixante-dix', 'Quatre-vingts', 'Quatre-vingt Dix')
denom_mg = ('',
            'Mille', 'Millions', 'Milliards', 'Billions', 'Quadrillions',
            'Quintillion', 'Sextillion', 'Septillion', 'Octillion', 'Nonillion',
            'Décillion', 'Undecillion', 'Duodecillion', 'Tredecillion', 'Quattuordecillion',
            'Sexdecillion', 'Septendecillion', 'Octodecillion', 'Icosillion', 'Vigintillion')


def _convert_nn_mg(val):
    """Convert a value < 100 to French."""
    if val < 20:
        return to_19_mg[val]
    for (dcap, dval) in ((k, 20 + (10 * v)) for (v, k) in enumerate(tens_mg)):
        if dval + 10 > val:
            if val % 10:
                if dval == 70 or dval == 90:
                    return tens_mg[int(dval / 10 - 3)] + '-' + to_19_mg[val % 10 + 10]
                else:
                    return dcap + '-' + to_19_mg[val % 10]
            return dcap


def _convert_nnn_mg(val):
    """
    Convert a value < 1000 to french.

    special cased because it is the level that kicks
    off the < 100 special case.  The rest are more general.  This also allows you to
    get strings in the form of 'forty-five hundred' if called directly.
    """
    word = ''
    (mod, rem) = (val % 100, val // 100)
    if rem > 0:
        if to_19_mg[rem] == "Un":
            word = 'Cent'
        else:
            word = to_19_mg[rem] + ' Cent'
        if mod > 0:
            word += ' '
    if mod > 0:
        word += _convert_nn_mg(mod)
    return word


def french_number(val):
    if val < 100:
        return _convert_nn_mg(val)
    if val < 1000:
        return _convert_nnn_mg(val)
    for (didx, dval) in ((v - 1, 1000 ** v) for v in range(len(denom_mg))):
        if dval > val:
            mod = 1000 ** didx
            l = val // mod
            r = val - (l * mod)
            if l == 1 and didx == 1:
                ret = denom_mg[didx]
            else:
                ret = _convert_nnn_mg(l) + ' ' + denom_mg[didx]
            if r > 0:
                ret = ret + ' ' + french_number(r)
            return ret


def amount_to_text_mg(number, currency):
    """
    To call it, first import convert module.

    from odoo.addons.convert import convert
    And then
    convert.amount_to_text_mg(rec.amount, 'Ariary')
    """
    number = '%.2f' % number
    units_name = currency
    list = str(number).split('.')
    start_word = french_number(abs(int(list[0])))
    decimal_word = french_number(int(list[1]))
    if decimal_word != u'Zéro':
        start_word += ' virgule ' + decimal_word
    final_result = start_word + ' ' + units_name
    return final_result
# -------------------------------------------------------------
