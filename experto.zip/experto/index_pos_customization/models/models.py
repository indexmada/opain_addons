# -*- coding: utf-8 -*-

from odoo import models, fields, api

class ProductTemplate(models.Model):
	_inherit="product.template"

	def get_original_price_by_id(self, product_id):
		product_tmpl = self.sudo().browse(int(product_id))
		return product_tmpl.lst_price
